package com.rdwhite.spotifystreamer;

/**
 * Created by 752632 on 7/13/2015.
 */
public class Util {

    public static boolean isStringNullOrEmpty(String s) {
        return s == null || s.isEmpty();
    }
}
